# static_index_mapping.hpp 文档

## 文件概述

`static_index_mapping.hpp` 提供了基于静态类型和宏的“静态索引映射”机制，允许在编译期定义一组索引（枚举）与常量值的映射，并以类似容器的接口进行访问。该机制适用于需要高效、类型安全、零运行时开销的静态映射场景。

## 命名空间结构

- `yggr`
  - `mapping`
    - `static_index_mapping<Tag>`
    - `mapping_indexes<Tag>`
    - `mapping_values<Tag>`

## 主要内容

### 1. 主要模板与宏
- `mapping_indexes<Tag>`：用于定义索引（枚举），通过宏展开生成。
- `mapping_values<Tag>`：用于定义与索引对应的常量值数组。
- `static_index_mapping<Tag>`：主静态映射容器，提供 begin/end/at/front/back/size/empty 等静态接口。
- 宏定义：
  - `YGGR_PP_STATIC_MAPPING_INDEXES_BEGIN/END`、`YGGR_PP_STATIC_MAPPING_INDEX`：定义索引枚举。
  - `YGGR_PP_STATIC_MAPPING_VALUES_DECLEAR/BEGIN/END`、`YGGR_PP_STATIC_MAPPING_VALUE`：定义值数组。
  - `YGGR_PP_STATIC_MAPPING_MAKE`：生成完整静态映射类型。
  - `YGGR_PP_GET_STATIC_MAPPING_INDEX/GET_STATIC_MAPPING_VALUE` 等：便捷访问宏。

### 2. 典型用法

```cpp
// 定义标签类型
struct MyTag {};

// 定义索引
YGGR_PP_STATIC_MAPPING_INDEXES_BEGIN(MyTag)
    YGGR_PP_STATIC_MAPPING_INDEX(Foo)
    YGGR_PP_STATIC_MAPPING_INDEX(Bar)
YGGR_PP_STATIC_MAPPING_INDEXES_END()

// 定义值
YGGR_PP_STATIC_MAPPING_VALUES_BEGIN(MyTag, int)
    YGGR_PP_STATIC_MAPPING_VALUE(100)
    YGGR_PP_STATIC_MAPPING_VALUE(200)
YGGR_PP_STATIC_MAPPING_VALUES_END()

// 生成静态映射
YGGR_PP_STATIC_MAPPING_MAKE(YGGR_PP_GET_STATIC_MAPPING_INDEXES(MyTag), YGGR_PP_GET_STATIC_MAPPING_VALUES(MyTag))

// 访问
int v = YGGR_PP_GET_STATIC_MAPPING_VALUE(MyTag, Foo); // 100
```

### 3. 接口说明
- `static_index_mapping<Tag>::begin()/end()/rbegin()/rend()`：静态迭代器接口。
- `static_index_mapping<Tag>::at(idx)`：按索引访问值，带断言。
- `static_index_mapping<Tag>::front()/back()`：首/尾元素。
- `static_index_mapping<Tag>::size()/empty()`：元素数量/是否为空。
- 支持通过宏获取索引、值、大小。

## 依赖关系
- 依赖 `<yggr/base/yggrdef.h>`、Boost MPL、Preprocessor、断言等。
- 仅使用标准类型和简单模板。

## 典型场景
- 需要编译期常量映射、枚举到常量的高效查找。
- 静态配置、元编程、类型安全的静态表。

## License
详见项目根目录下 LICENSE 文件。
