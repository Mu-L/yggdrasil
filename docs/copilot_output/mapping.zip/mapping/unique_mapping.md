# unique_mapping.hpp 文档

## 文件概述

`unique_mapping.hpp` 实现了一个支持多关键字唯一映射的泛型容器 `unique_mapping`，可用于高效、安全地进行多字段唯一性约束的数据存储、查找、修改、交换等操作。该容器基于安全多索引容器（safe_multi_index_container），支持多关键字索引、变长模板参数、线程安全等特性。

## 命名空间结构

- `yggr`
  - `mapping`
    - `unique_mapping`
    - `swap_support`

## 主要内容

### 1. 模板结构
- `unique_mapping<Val1, Val2, ..., Mutex=void>`：
  - 支持变长模板参数，自动生成多关键字索引。
  - `value_type` 为 `packet::packet_info<...>`，每个字段可通过 `arg<i>` 访问。
  - 内部基于 `safe_multi_index_container`，支持多索引唯一性。
  - 支持线程安全（可选 Mutex）。

### 2. 主要接口
- 构造/赋值/拷贝/移动/析构。
- 容器操作：`clear`、`size`、`empty`、`swap`。
- 数据插入：`append`、`compulsory_append`、`compulsory_exchange`，支持变参构造。
- 数据删除：`remove`（支持按 Tag 或索引）。
- 存在性判断：`is_exists`。
- 数据修改：`modify`（支持变参，按 Tag 或索引）。
- 数据交换：`exchange`（支持变参，按 Tag 或索引）。
- 映射查询：`mapping_value`、`mapping_other_values`，支持单值和批量查询。
- 静态工具：`create_tag_object<i>()`。
- 支持 swap（与 std/boost 兼容）。

### 3. 设计与实现要点
- 多关键字唯一性：每个字段都可作为唯一索引，插入时自动判重。
- 变参模板与宏兼容：支持 C++11 及更早版本。
- 线程安全：可选 Mutex 参数。
- 支持高效查找、修改、批量映射等高级操作。

## 依赖关系
- 依赖 `safe_multi_index_container`、`packet_info`、`copy_or_move_or_swap`、`boost::multi_index`、`boost::mpl`、`boost::bind`、`yggr::swap` 等。
- 支持 C++11 变参模板和宏展开两种实现。

## 用法示例

```cpp
#include <yggr/mapping/unique_mapping.hpp>

// 定义一个三字段唯一映射
using umap = yggr::mapping::unique_mapping<int, std::string, double>;
umap m;
m.append(1, "foo", 3.14);
bool exists = m.is_exists<umap::value_type::arg<1>>("foo");
```

## 典型场景
- 多关键字唯一性数据表、索引映射、去重存储。
- 需要高效查找、批量修改、线程安全的数据结构。

## License
详见项目根目录下 LICENSE 文件。
